---
name: Obsidian Sentinel
colors:
  surface: '#121318'
  surface-dim: '#121318'
  surface-bright: '#38393f'
  surface-container-lowest: '#0d0e13'
  surface-container-low: '#1a1b21'
  surface-container: '#1e1f25'
  surface-container-high: '#292a2f'
  surface-container-highest: '#34343a'
  on-surface: '#e3e1e9'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#e3e1e9'
  inverse-on-surface: '#2f3036'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#ca8100'
  on-tertiary-container: '#3e2400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#121318'
  on-background: '#e3e1e9'
  surface-variant: '#34343a'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-xs:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 0.75rem
  gutter-tablet: 1rem
  margin: 1rem
  margin-tablet: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

The design system marries enterprise-grade administrative authority with the tactile warmth and fluid velocity of consumer-grade mobile applications. Designed for student IT workers, campus desk technicians, and junior administrators managing fleet devices on the move, the UI departs from dense, intimidating desktop dashboards. It embraces an ultra-clean, modern dark aesthetic inspired by the disciplined typography of Linear, the modular clarity of Notion Mobile, and the approachable utility of modern Android workspace apps.

The aesthetic philosophy centers on **Refined Tactical Minimalism**:
- **Clarity under pressure:** Critical status signals (device compliance, lock status, fleet health) must be discernible at a single glance during dynamic, on-foot campus support operations.
- **Friendly precision:** Avoid dry bureaucratic tables. Utilize structured information cards, generous tap footprints, responsive micro-states, and fluid tactile feedback.
- **Confidence through structure:** Deep atmospheric dark backgrounds paired with hairline borders eliminate visual noise while maintaining clear physical hierarchy without heavy drop shadows.

## Colors

The palette is engineered specifically for deep OLED power preservation and sustained legibility across varying outdoor and indoor lighting conditions on mobile hardware.

### Foundations & Surfaces
- **Canvas Base (`#090A0F`):** Deep abyssal slate providing optimal contrast and battery conservation. Used for window backdrops and global views.
- **Surface Elevated (`#12141C`):** Primary layer for floating lists, cards, and modal sheets.
- **Surface Highlight (`#1A1D27`):** Interactive fill, active row indicators, and nested card groupings.
- **Borders & Dividers (`#262B3A`):** Low-attenuation, crisp structural lines separating dense administrative information.

### Primary Accents & Signals
- **Electric Blue Primary (`#3B82F6` resting, `#60A5FA` focus/hover):** Commands attention for primary device actions (Wipe, Push Profile, Sync, Verify).
- **Emerald Green Success (`#10B981` resting, `#34D399` tint):** Denotes compliant devices, active MDM check-ins, and verified cryptographic certificates.
- **Amber Warning (`#F59E0B` resting, `#FBBF24` tint):** Flags pending OS updates, low storage, or non-critical policy drift.
- **Rose Alert (`#F43F5E` resting, `#FB7185` tint):** Highlights security breaches, failed unlock attempts, root detections, and unmanaged devices.

## Typography

The type system is powered by **Plus Jakarta Sans**, chosen for its friendly geometric curves paired with precise architectural legibility.

- **Scale Ratio:** A compact modular scale tuned for handheld ergonomic viewports, preventing awkward string truncations in localized hardware titles.
- **Numbers & Telemetry:** Uses tabular figures (`tnum`) for battery percentages, IP addresses, serial numbers, and enrollment timers to prevent layout jittering during real-time sync events.
- **Visual Weighting:** Medium (500) and SemiBold (600) weights dominate labels to maintain crisp character definition against dark backgrounds without blooming.

## Layout & Spacing

A mobile-first fluid layout standard tailored for modern tall aspect ratio touch devices (19.5:9 to 20:9), scaling gracefully to foldable and tablet form factors.

- **Grid Architecture:** Single-column fluid viewports on mobile with a default outer margin of `16px` (`margin`). Tablets (600dp+) transition into a 2-column or 3-column asymmetric layout with `24px` (`margin-tablet`) edge gutters.
- **Touch Target Law:** Every interactive element adheres to a minimum strict bounding box of 48×48dp, even when the visible iconography or badge is smaller.
- **Vertical Rhythm:** Rooted in an 8dp baseline grid with 4dp sub-steps for micro adjustments. Spacing tokens strictly delineate distance between sibling elements and container edges.

## Elevation & Depth

Visual hierarchy is communicated through **structural tonal layering** combined with **subtle low-contrast outlines**, eliminating muddy or washed-out shadows on OLED screens.

- **Layer 0 (Canvas):** Pure `#090A0F`. Non-interactive backdrop.
- **Layer 1 (Card/List Surface):** `#12141C` paired with a precise `1px` solid border in `#262B3A`. Gives a crisp floating panel feel.
- **Layer 2 (Interactive Floating / Active State):** `#1A1D27` with border `#333A4E`.
- **Layer 3 (Modals / Bottom Sheets):** `#1A1D27` overlay surface elevated with a directional ambient glow: `0px 12px 32px -8px rgba(0, 0, 0, 0.6)`.
- **Active State Feedback:** Tapping interactive panels triggers an instantaneous tint transition toward primary blue at 8% opacity (`rgba(59, 130, 246, 0.08)`) with zero layout shift.

## Shapes

The interface embraces a friendly, hyper-modern rounded geometry that softens technical administrative tasks and feels intrinsic to modern Android hardware.

- **Base Radius (16px / `rounded-lg`):** Standard for cards, modal dialogs, status banners, and bottom sheets.
- **Accent Elements (8px to 12px):** Used for micro badges, policy tags, and sub-metric boxes.
- **Pill Geometry (Full Radius):** Reserved for primary action pills, status indicators, and segment switchers to create instantaneous visual contrast against rectilinear content blocks.

## Components

### Buttons & Interactive Controls
- **Primary Action Button:** Height 48px min. Background `#3B82F6`, label `#FFFFFF` in `label-lg`, radius `16px`. Active compression scale down to 98% on touch down.
- **Secondary / Ghost Button:** Background `#1A1D27`, border `1px solid #262B3A`, text `#E2E8F0`. Focus state rings with `2px solid #60A5FA`.
- **Destructive Wipe Action:** Background `rgba(244, 63, 94, 0.12)`, border `1px solid rgba(244, 63, 94, 0.3)`, text `#FB7185`. Requires press-and-hold confirmation.

### Device Fleet Cards
- Container in `#12141C` with `1px solid #262B3A` border and `16px` radius.
- Top row displays Device Name (`title-md`) alongside a prominent compliance status badge (Pill, `10px` uppercase text with a `6px` glowing status dot).
- Subtitle provides OS version and student user ID in `#94A3B8`.
- Quick-action swipe reveals contextual action shortcuts (Lock, Ping, Sync).

### Status Badges & Chips
- Fully pill-shaped with `8px` vertical and `12px` horizontal padding.
- **Compliant:** `#10B981` at 12% opacity fill, `#34D399` text.
- **Pending/Stale:** `#F59E0B` at 12% opacity fill, `#FBBF24` text.
- **Non-Compliant:** `#F43F5E` at 12% opacity fill, `#FB7185` text.

### Inputs & Search
- Height 48px, background `#12141C`, border `1px solid #262B3A`, corner radius `16px`.
- Placeholder `#64748B`. Integrated barcode/QR scan icon on the trailing edge for student hardware serial scanning.

### Bottom Sheet Drawers
- Anchored to the viewport bottom with `24px` top corners.
- Subtle central drag handle (`36px × 4px`, background `#333A4E`).
- Houses deep device policy configuration tools without breaking spatial context.